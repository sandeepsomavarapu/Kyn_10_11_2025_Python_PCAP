from abc import *
#normal class
class Test:
    #abstract method
    @abstractmethod
    def m1(self):
        pass
#abstract class
class Demo(ABC):
    @abstractmethod
    def m2(self):
        pass    
test=Test() #can create object for normal class
demo=Demo() #can not create object for abstract class


