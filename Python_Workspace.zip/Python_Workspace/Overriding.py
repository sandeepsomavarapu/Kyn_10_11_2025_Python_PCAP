class Parent:
    def __init__(self):
        print("Parent class constructor")

    def display(self):
        print("Parent method")

class Child(Parent):
    def __init__(self):
        print("Child class constructor")

    def display(self):
        print("Child method")    
        super().display()
  

child=Child()
child.display()

