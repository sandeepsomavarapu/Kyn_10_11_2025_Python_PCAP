class Employee:
    id=123   #data members
    name="sai"
    def __init__(self):
        print("Employee class constructor")
    #member functions
    def display(self):
        print("Employee class display method")
    def  login(self):
        print("Employee class login method")
class SoftwareEmployee(Employee):
    tools="jira"
    def __init__(self):
        print("SoftwareEmployee class constructor")
    def m1(self):
        print("SoftwareEmployee class m1 method")    
class HardwareEmployee(Employee):
    workingHours=10
    def __init__(self):
        print("HardwareEmployee class constructor")
    def m2(self):
        print("HardwareEmployee class m2 method")
semp=SoftwareEmployee()
print(semp)
semp.m1()
semp.display()
semp.login()
print(semp.id)
print(semp.name)
print(semp.tools)

hemp=HardwareEmployee()
print(hemp)
hemp.m2()
hemp.display()
hemp.login()
# print(hemp.tools)  we cannot access
print(hemp.id)
print(hemp.name)
print(hemp.workingHours)
# hemp.m1() we cant access


