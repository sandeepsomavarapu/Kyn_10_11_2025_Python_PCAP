# numbers=[[10,20,30],[40,50,60],[70,80,90]]#-->3 numbers[2][1]

# for l in numbers:#0 ->[10,20,30]
#     for y in l:     #0 10
#         print(y,end=' ')
#     print()    


numbers=[[10,20,30],[40]]

for number in numbers:
    for num in number:
        print(num, end=' ')
    print()    