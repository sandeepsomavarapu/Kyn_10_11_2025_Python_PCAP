print('Excelr123'.isalnum())# anyone from this .... a-z A-Z 0-9
print('Excelr123'.isalpha())# anyone from this .... a-z A-Z 
print('Excelr'.isalpha())# anyone from this .... a-z A-Z 
print('excelr'.isdigit())# anyone from this .... 0-9
print('12345'.isdigit())# anyone from this .... 0-9
print('excelr'.islower())# anyone from this .... a-z
print('EXCELR'.isupper())# anyone from this .... a-z
print('Excelr India'.istitle())# anyone from this .... a-z
print('excelr'.isspace())