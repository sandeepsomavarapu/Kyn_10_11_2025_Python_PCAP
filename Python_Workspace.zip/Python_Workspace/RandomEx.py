from random import *
from random import randint
from random import choice

# for i in range(10):
#     print(random())

# for i in range(10):
#     print(randint(1, 100))

list=["suresh","naresh",'rajesh','hitesh','somesh','hitesh']

for i in range(10):
    print(choice(list))