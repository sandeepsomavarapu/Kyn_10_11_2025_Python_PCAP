class Person:
    a=123 #public variable
    _b=123 #protected variable
    def __init__(self,name,age):
        self.name=name
        self.age=age
    def display(self):
        print("Name:",self.name)
        print("Age:",self.age)   

class Student(Person):
    def __init__(self, name, age, rollno,marks):
        super().__init__(name, age)# parent constructor calling super()
        print(Person.a)
        self.rollno=rollno
        self.marks=marks
        self.display()# current class function calling using self
    def display(self):
        super().display()# parent class function calling using super()
        print("Roll No:", self.rollno)
        print("Marks:", self.marks)  
        print("student Name:",self.name)# parent class variable calling using   
        #print("student Name:",Person.name)# parent class variable calling using   

student =Student('suresh',22,12345,999)
