
# file=open("data.txt","w")
# file.write("Hello World\n")
# file.write("Welcome to Python\n")
# file.write("This is a sample file\n")
# file.close()
# print("File created successfully")

# file=open("data.txt",'r')
# print(file.read(5))
# print(file.read())
# for line in file:
#     print(line)


# file=open("data3.txt","a")#w,x,r,a,t
# file.write("am from  hyd\n")
# file.close()
# print("File created successfully")



# file=open("data3.txt",'r')
# # print(file.read(5))
# # print(file.read())
#print(file.readline())
# print(file.readlines())

#pickling->the proceess of converting object data to byte data
class Employee:
    def __init__(self, id, name, salary):
        self.id=id
        self.name=name
        self.salary=salary
    def display(self):
        print("ID:", self.id)
        print("Name:", self.name)
        print("Salary:", self.salary)

# emp=Employee(1, "John", 10000)
# emp.display()
# import pickle

# file=open("emp.data", "wb")
# pickle.dump(emp, file)

#un-pickling
import pickle

file=open("emp.data", "rb")
obj=pickle.load(file)
print(obj.__dict__)




