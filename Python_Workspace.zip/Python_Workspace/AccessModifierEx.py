class Test:
    x=123
    _y=234
    __z=345

    def m1(self):
        print(Test.x)
        print(Test._y)
        print(Test.__z)
test=Test()
test.m1()
print(Test.x)        
print(Test._y)  
print(test._Test__z)   #not recommended
print(Test.__z) #private cannot be accessed outside the class
