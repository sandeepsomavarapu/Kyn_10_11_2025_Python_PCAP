class Student:
    def __init__(self, name, age, grade):
        self.name = name
        self.age = age
        self.grade = grade
    def display(self):
        print("Name:", self.name)
        print("Age:", self.age)
        print("Grade:", self.grade)
    def __str__(self):
        return f"Name: {self.name}, Age: {self.age}, Grade: {self.grade}"

student = Student("Alice", 20, "A")
print(student)            
# print(student.__dict__)  