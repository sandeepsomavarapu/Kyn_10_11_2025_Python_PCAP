class GrandParent:
    def m1(self):
        print("GrandParent class m1 method")
class Parent(GrandParent):
    def m2(self):
        print("Parent class m2 method")        
class Child(Parent):
    def m3(self):
        print("Child class m3 method")
child=Child()
child.m1()
child.m2()
child.m3()
