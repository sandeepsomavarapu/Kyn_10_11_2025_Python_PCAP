from math import *
from math import ceil
from math import floor
from math import factorial
import math
print(sqrt(4))
print(ceil(3.7))
print(floor(3.7))
print(pow(3, 2))
print(factorial(5))
print(fabs(-12))

help(math)