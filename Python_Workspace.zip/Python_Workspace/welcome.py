print("Hello World")

a=int(12.34)
#add function
def add(a,b):
    print(a+b)
add(10,20)

#sub function
def sub(a, b):
    return a-b

x=sub(200, 100)

print("sub of 20,10 :",sub(20, 10))

#display function
def displayMsg():
    print("Hello World")#prints helloworld
    print("Hello World")
    print("Hello World")

displayMsg()    

#ctrl+~
