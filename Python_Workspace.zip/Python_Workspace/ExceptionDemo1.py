class InsufficientBalance(BaseException):
    def __init__(self, msg):
        self.msg=msg

x=int(input("Enter your account number:"))
y=int(input("Enter amount to withdraw "))
 
balance=10000
if(y>balance):
 raise InsufficientBalance("No Funds")
else:
    print("Transaction successful")

