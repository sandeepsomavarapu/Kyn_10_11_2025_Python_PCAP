class Employee:
    def __init__(self,id,name,salary):#inside constructor
        #inside the constructor using self 
        self.id = id
        self.name = name
        self.salary = salary #instance variables
        print("id:", self.id)
    def display(self):#instance method
        print("id:", self.id)
        print("name:", self.name)
        print("salary:", self.salary)
        self.deignation="admin"# instance variable

emp=Employee(123, 'sai', 10000)
emp.email='sai@gmail.com'#obj reference
emp.display()
print(emp.__dict__)
print(emp.id)#accessing instance variable using obj reference
emp1=Employee(124, 'suresh',20000)
emp1.email='suresh@gmail.com'#obj reference
emp1.display()
print(emp1.__dict__)
print(emp1.id)