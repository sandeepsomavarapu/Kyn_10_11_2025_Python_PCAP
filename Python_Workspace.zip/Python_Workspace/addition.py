#dynamic input
fnum=int(input("Enter your first number")) #'123' 123
snum=int(input("Enter your second number")) #'124' 124
result=fnum+snum
print("The Addition of two numbers: ",result)

salary=float(input("Enter your salary: "))
print("My salary is: ", salary)
print(type(salary))

condition=bool(input("Enter your result: "))
print("My result is: ", condition)
print(type(condition))

info=[result,salary,condition]

print(info)