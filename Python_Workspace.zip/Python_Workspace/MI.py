
class Calculator:
   def add(self,a,b):
      print("add")
      return a+b
class MobileCalculator:
   def add(self,a,b):
      print("addition")
      return a+b
   def sub(self,a,b):
      return a-b
class ScientificCalculator(MobileCalculator,Calculator):
   def mul(self, a, b):
      return a*b   
obj=ScientificCalculator()
print(obj.add(2,3))
print(obj.sub(5, 3))
print(obj.mul(2, 3))

      
