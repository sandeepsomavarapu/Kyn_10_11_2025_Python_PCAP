# print(10/"ten")#pvm
a=12
b=2
try:
    result=a/b
    print("result=",result)
except ZeroDivisionError:
    print("Error: Division by zero is not allowed.")
else:
    print("Division successful.")    
print("Remaining 1000 lines.....")

