def outer(x):
    def inner(y):
        return x + y
    return inner

add_five = outer(5)
result = add_five(6)
result1 = add_five(600)
print(result)
print(result1)