
import ModuleDemo
# import ModuleDemo as md
# from ModuleDemo import add as sum, sub, x
# from ModuleDemo import *


print(ModuleDemo.add(12,23))
print(ModuleDemo.sub(12,23))
print(ModuleDemo.x)
print(dir(ModuleDemo))

print(__name__)
print(ModuleDemo.__name__)