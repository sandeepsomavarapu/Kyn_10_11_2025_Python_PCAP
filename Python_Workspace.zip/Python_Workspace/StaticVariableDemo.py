

class Product:
    def __init__(self):

        Product.productCategory = "electronics"# static variable inside constcurcotq
    def m1(self):
        a=123#//local variable
        print(a)
        Product.productDesc="it is electronics product"
product=Product()
product.m1()
print(product.productDesc)        
print(product.productCategory)  
print(Product.productCategory)        #Recommended to access static variable using class name
print(Product.productDesc)                                      