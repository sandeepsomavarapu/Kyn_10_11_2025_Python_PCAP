# import sys

# print(sys.path)

import platform as obj


# print(obj.system())
# print(obj.processor())
# print(obj.machine())
# print(obj.version())
# print(obj.platform())
# print(obj.uname())
# print(obj.node())
# print(obj.release())
# print(obj.architecture())
