print("this is from ModuleDemo")
x=123

def add(a,b):
    return a+b
def sub(x,y):
    return x-y
print(dir())