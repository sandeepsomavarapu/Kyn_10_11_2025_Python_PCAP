class Test:
    
    def m1(self):
        print("this is m1")
    def m1(self,name):
        print("this is m2")
    def m1(self,name, age):
        print("this is m3")    
    def m1(self,a=None,b=None,c=None):
        if a!=None and b!=None and c!=None:
            print("sum of three numbers", a+b+c)
        elif a!=None and b!=None:
            print("sum of two numbers", a+b)
        else:
            print("please provide 2 or 3 arguments")        
test=Test()
test.m1(12, 20)         
test.m1(22)   
test.m1(10, 20, 30)

class Hello:
    def __init__(self):
        pass
    def __init__(self, name):
        print("this is constructor")
        self.name=name
    def __init__(self, name, age):
        print("this is constructor")
        self.name=name
        self.age=age    
hello= Hello('mahesh',90)        