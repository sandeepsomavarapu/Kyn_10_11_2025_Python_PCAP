
orgname="kyndryl"
if orgname=="kyndryl":
    print("welcome to kyndryl")
elif orgname=="cisco":
    print("welcome to cisco")    
else:
    print("welcome to other orgs")

listOfNames=["sai","ram","krishna","venkat"]
for name in listOfNames:
    print(name)

while listOfNames:
    print("list is not empty")
    break
else:
    print("list is empty")


    